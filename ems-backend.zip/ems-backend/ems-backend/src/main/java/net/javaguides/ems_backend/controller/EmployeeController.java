package net.javaguides.ems_backend.controller;


import lombok.AllArgsConstructor;
import net.javaguides.ems_backend.dto.EmployeeDto;
import net.javaguides.ems_backend.service.EmployeeService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@AllArgsConstructor

// handle http request
@RestController
@RequestMapping("/api/employees")
public class EmployeeController {
    private EmployeeService employeeService;


   //Build Add Employee REST API
   @PostMapping
 public ResponseEntity<EmployeeDto> createEmployee(@RequestBody EmployeeDto employeeDto){
   EmployeeDto savedEmployee =  employeeService.createEmployee(employeeDto);
   return new ResponseEntity<>(savedEmployee, HttpStatus.CREATED);
}

// Build Get Employee Rest Api
    @GetMapping("{id}")
    public ResponseEntity<EmployeeDto> getEmployeeById(@PathVariable("id") Long employeeId){
       EmployeeDto employeeDto = employeeService.getEmployeeByid(employeeId);
       return ResponseEntity.ok(employeeDto);
    }

// update employee Rest Api
   @PutMapping("{id}")
    public ResponseEntity<EmployeeDto> updateEmployee(@PathVariable("id") Long employId, @RequestBody EmployeeDto updatedEmployee){
      EmployeeDto employeeDto =  employeeService.updateEmployee(employId, updatedEmployee);
      return ResponseEntity.ok(employeeDto);
    }

 // Build Delete employee rest api
@DeleteMapping("{id}")
 public ResponseEntity<String> deleteEmployee(@PathVariable("id") Long employeeId){
       employeeService.deleteEmployee(employeeId);
       return ResponseEntity.ok("Employee Deleted Successfully");

 }



    


}
