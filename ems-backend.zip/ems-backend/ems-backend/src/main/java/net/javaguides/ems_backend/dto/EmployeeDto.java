package net.javaguides.ems_backend.dto;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor

// dto allow us to transfer data between different layer

// employeedto allow us to transfer data between client ems server

public class EmployeeDto {
    private Long id;
    private String firstName;
    private String lastName;
    private String emailId;

}
