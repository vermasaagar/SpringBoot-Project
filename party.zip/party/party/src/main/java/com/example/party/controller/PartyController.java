package com.example.party.controller;


import com.example.party.Service.PartyService;
import com.example.party.dto.PartyRequest;
import com.example.party.dto.PartyResponse;
import com.example.party.entity.Party;
import com.example.party.mapper.PartyMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
@RequestMapping("/create")
public class PartyController {

    private final PartyService partyService;
    private final PartyMapper partyMapper;


    @PostMapping("/party")
    public PartyResponse addParty(@RequestBody PartyRequest request) {
        Party party = partyMapper.fromDtoToEntity(request);
        Party savedParty = partyService.addparty(party);
        return partyMapper.fromEntityToDto(savedParty);

    }
}