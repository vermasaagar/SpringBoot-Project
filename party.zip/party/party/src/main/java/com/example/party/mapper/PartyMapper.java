package com.example.party.mapper;

import com.example.party.dto.PartyRequest;
import com.example.party.dto.PartyResponse;
import com.example.party.entity.Party;
import org.mapstruct.Mapper;

@Mapper
public abstract class PartyMapper {

    public abstract Party fromDtoToEntity(PartyRequest partyRequest);

    public abstract PartyResponse fromEntityToDto(Party party);

}
