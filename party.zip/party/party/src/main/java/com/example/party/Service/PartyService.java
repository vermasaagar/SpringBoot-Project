package com.example.party.Service;


import com.example.party.entity.Party;
import com.example.party.repo.PartyRepository;
import org.springframework.stereotype.Service;

@Service
public class PartyService {

    private final PartyRepository partyRepo;

    public PartyService(PartyRepository partyRepo) {
        this.partyRepo = partyRepo;
    }

    public Party addparty(Party party) {
        return partyRepo.save(party);
    }
}