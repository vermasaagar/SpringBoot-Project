package com.example.party.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PartyResponse {

    private Long id ;
    private String name;
    private String logo;
    private Integer members;
    private String mainLeader;

}